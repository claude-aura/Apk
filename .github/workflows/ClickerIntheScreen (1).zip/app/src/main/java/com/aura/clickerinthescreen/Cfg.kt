package com.aura.clickerinthescreen

import android.content.Context
import android.content.SharedPreferences
import kotlin.properties.ReadWriteProperty
import kotlin.reflect.KProperty

class Cfg(ctx: Context) {
    val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("cits", Context.MODE_PRIVATE)

    var limitSec by IntP("limitSec", 2)          // 0 = sem limite
    var textSizeSp by IntP("textSizeSp", 28)
    var textColor by IntP("textColor", 0xFFFFFFFF.toInt())
    var showCounter by BoolP("showCounter", true)
    var showCps by BoolP("showCps", true)
    var overlayOn by BoolP("overlayOn", false)
    var spyOn by BoolP("spyOn", false)
    var overlaySizeDp by IntP("overlaySizeDp", 140)
    var ovX by IntP("ovX", 40)
    var ovY by IntP("ovY", 300)
    var imgVersion by IntP("imgVersion", 0)

    /** Grava X e Y de uma vez (evita o clicker "pular" por causa do listener). */
    fun setPos(x: Int, y: Int) {
        sp.edit().putInt("ovX", x).putInt("ovY", y).apply()
    }
}

private class IntP(val k: String, val d: Int) : ReadWriteProperty<Cfg, Int> {
    override fun getValue(thisRef: Cfg, property: KProperty<*>) = thisRef.sp.getInt(k, d)
    override fun setValue(thisRef: Cfg, property: KProperty<*>, value: Int) {
        thisRef.sp.edit().putInt(k, value).apply()
    }
}

private class BoolP(val k: String, val d: Boolean) : ReadWriteProperty<Cfg, Boolean> {
    override fun getValue(thisRef: Cfg, property: KProperty<*>) = thisRef.sp.getBoolean(k, d)
    override fun setValue(thisRef: Cfg, property: KProperty<*>, value: Boolean) {
        thisRef.sp.edit().putBoolean(k, value).apply()
    }
}

package com.aura.clickerinthescreen

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.hypot

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** View única usada no app e no overlay: imagem (parada/clique/segurando) + contador. */
class ClickerView(
    ctx: Context,
    private val engine: ClickEngine,
    private val cfg: Cfg
) : LinearLayout(ctx) {

    private val image = ImageView(ctx).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
    private val label = TextView(ctx).apply {
        gravity = Gravity.CENTER
        setShadowLayer(6f, 0f, 0f, Color.BLACK)
        setPadding(0, ctx.dp(4), 0, ctx.dp(4))
    }
    private var idleBmp: Bitmap? = null
    private var clickBmp: Bitmap? = null
    private var holdBmp: Bitmap? = null
    private var shownState: ClickEngine.State? = null

    init {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        addView(image, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(
            label,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        engine.onFinished = { c, cps ->
            announceForAccessibility(context.getString(R.string.announce_done, c, cps))
        }
        reload()
    }

    /** Tamanho fixo da imagem (usado no overlay). */
    fun setImageSize(px: Int) {
        image.layoutParams = LinearLayout.LayoutParams(px, px)
    }

    fun reload() {
        idleBmp = ImageStore.load(context, Slot.IDLE)
        clickBmp = ImageStore.load(context, Slot.CLICK)
        holdBmp = ImageStore.load(context, Slot.HOLD)
        shownState = null
        restyle()
    }

    fun restyle() {
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, cfg.textSizeSp.toFloat())
        label.setTextColor(cfg.textColor)
        label.visibility = if (cfg.showCounter) View.VISIBLE else View.GONE
        refresh()
    }

    fun refresh() {
        val st = engine.state
        if (st != shownState) {
            shownState = st
            val bmp = when (st) {
                ClickEngine.State.IDLE -> idleBmp
                ClickEngine.State.CLICK -> clickBmp ?: idleBmp
                ClickEngine.State.HOLD -> holdBmp ?: clickBmp ?: idleBmp
            }
            if (bmp != null) image.setImageBitmap(bmp)
            else image.setImageResource(
                when (st) {
                    ClickEngine.State.IDLE -> R.drawable.ic_idle
                    ClickEngine.State.CLICK -> R.drawable.ic_click
                    ClickEngine.State.HOLD -> R.drawable.ic_hold
                }
            )
        }
        val c = context
        val txt = when {
            engine.finished ->
                if (cfg.showCps) c.getString(R.string.done_cps, engine.count, engine.cps)
                else c.getString(R.string.done, engine.count)
            engine.running && engine.limitMs > 0 ->
                c.getString(
                    R.string.running, engine.count,
                    (engine.limitMs - engine.elapsedMs).coerceAtLeast(0) / 1000f
                )
            else -> c.getString(R.string.count_only, engine.count)
        }
        if (label.text.toString() != txt) label.text = txt
        if (!engine.running) image.contentDescription = c.getString(R.string.cd_area, txt)
    }

    /**
     * Toque = clique; segurar = imagem "segurando"; se [onDrag] existir, arrastar move a view
     * (o toque deixa de contar como clique).
     */
    @SuppressLint("ClickableViewAccessibility")
    fun enableTouch(onDrag: ((Float, Float) -> Unit)? = null, onDragEnd: (() -> Unit)? = null) {
        val slop = ViewConfiguration.get(context).scaledTouchSlop * 2
        var sx = 0f; var sy = 0f; var lx = 0f; var ly = 0f
        var dragging = false
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; lx = sx; ly = sy; dragging = false
                    engine.down(cfg.limitSec)
                }
                MotionEvent.ACTION_MOVE -> if (onDrag != null) {
                    if (!dragging && hypot(e.rawX - sx, e.rawY - sy) > slop) {
                        dragging = true
                        engine.cancelTouch()
                    }
                    if (dragging) onDrag(e.rawX - lx, e.rawY - ly)
                    lx = e.rawX; ly = e.rawY
                }
                MotionEvent.ACTION_UP -> {
                    if (dragging) onDragEnd?.invoke() else engine.up()
                    dragging = false
                    v.performClick()
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (!dragging) engine.up()
                    dragging = false
                }
            }
            true
        }
    }
}

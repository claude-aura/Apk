package com.aura.clickerinthescreen

import android.os.Handler
import android.os.Looper
import android.os.SystemClock

/** Máquina de estados do clicker: IDLE -> CLICK -> HOLD e contagem por rodada com limite de tempo. */
class ClickEngine(private val onChange: () -> Unit) {

    enum class State { IDLE, CLICK, HOLD }

    var state = State.IDLE
        private set
    var count = 0
        private set
    var running = false
        private set
    var finished = false
        private set
    var elapsedMs = 0L
        private set
    var limitMs = 0L
        private set
    var onFinished: ((Int, Float) -> Unit)? = null

    val cps: Float get() = if (limitMs > 0) count * 1000f / limitMs else 0f

    private val h = Handler(Looper.getMainLooper())
    private var startAt = 0L
    private var finishedAt = 0L
    private var isDown = false
    private var counted = false

    private val holdR = Runnable {
        if (isDown && state == State.CLICK) { state = State.HOLD; onChange() }
    }
    private val releaseR = Runnable {
        if (!isDown && state != State.IDLE) { state = State.IDLE; onChange() }
    }
    private val tickR = object : Runnable {
        override fun run() {
            elapsedMs = SystemClock.uptimeMillis() - startAt
            if (limitMs > 0 && elapsedMs >= limitMs) { finish(); return }
            onChange()
            h.postDelayed(this, 50)
        }
    }

    fun down(limitSec: Int) {
        val now = SystemClock.uptimeMillis()
        h.removeCallbacks(releaseR); h.removeCallbacks(holdR)
        isDown = true; counted = false
        if (finished && now - finishedAt >= LOCKOUT_MS) clear()
        if (!finished) {
            if (!running) {
                running = true; count = 0
                limitMs = limitSec * 1000L
                startAt = now; elapsedMs = 0
                h.post(tickR)
            }
            count++; counted = true
        }
        state = State.CLICK
        h.postDelayed(holdR, HOLD_MS)
        onChange()
    }

    fun up() {
        isDown = false
        h.removeCallbacks(holdR)
        h.postDelayed(releaseR, RELEASE_MS)
    }

    /** O toque virou arrasto: desfaz a contagem desse toque. */
    fun cancelTouch() {
        h.removeCallbacks(holdR)
        isDown = false
        if (counted) {
            counted = false; count--
            if (count <= 0 && running) clear()
        }
        state = State.IDLE
        onChange()
    }

    fun reset() { clear(); onChange() }

    fun destroy() = h.removeCallbacksAndMessages(null)

    private fun clear() {
        h.removeCallbacks(tickR)
        running = false; finished = false
        count = 0; elapsedMs = 0
        state = State.IDLE
    }

    private fun finish() {
        h.removeCallbacks(tickR); h.removeCallbacks(holdR)
        running = false; finished = true
        finishedAt = SystemClock.uptimeMillis()
        elapsedMs = limitMs
        state = State.IDLE
        onFinished?.invoke(count, cps)
        onChange()
    }

    private companion object {
        const val HOLD_MS = 220L       // tempo pra virar "segurando"
        const val RELEASE_MS = 90L     // tempo mínimo mostrando a imagem de clique
        const val LOCKOUT_MS = 1000L   // ignora toques logo após o fim da rodada
    }
}

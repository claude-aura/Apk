package com.aura.clickerinthescreen

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max

enum class Slot(val file: String, val label: Int, val defRes: Int) {
    IDLE("idle.png", R.string.slot_idle, R.drawable.ic_idle),
    CLICK("click.png", R.string.slot_click, R.drawable.ic_click),
    HOLD("hold.png", R.string.slot_hold, R.drawable.ic_hold)
}

object ImageStore {
    private const val MAX_SIDE = 1024

    fun save(ctx: Context, uri: Uri, slot: Slot): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val bmp = ctx.contentResolver.openInputStream(uri)?.use {
                BitmapFactory.decodeStream(it, null, opts)
            } ?: return false
            FileOutputStream(File(ctx.filesDir, slot.file)).use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun remove(ctx: Context, slot: Slot) = File(ctx.filesDir, slot.file).delete()

    fun load(ctx: Context, slot: Slot): Bitmap? {
        val f = File(ctx.filesDir, slot.file)
        return if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
    }
}

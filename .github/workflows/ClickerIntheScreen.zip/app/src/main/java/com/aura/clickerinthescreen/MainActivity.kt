package com.aura.clickerinthescreen

import android.accessibilityservice.AccessibilityServiceInfo
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.view.accessibility.AccessibilityManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.Toast
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.aura.clickerinthescreen.databinding.ActivityMainBinding
import com.aura.clickerinthescreen.databinding.ItemSlotBinding

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var cfg: Cfg
    private lateinit var clicker: ClickerView
    private val engine = ClickEngine { if (::clicker.isInitialized) clicker.refresh() }
    private val thumbs = mutableMapOf<Slot, ImageView>()
    private var pending: Slot? = null

    private val picker = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        val slot = pending
        if (uri != null && slot != null) {
            if (ImageStore.save(this, uri, slot)) imagesChanged()
            else Toast.makeText(this, R.string.img_error, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        cfg = Cfg(this)
        pending = savedInstanceState?.getString("pending")?.let { Slot.valueOf(it) }

        clicker = ClickerView(this, engine, cfg).also {
            it.enableTouch()
            b.card.addView(it, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }
        b.btnReset.setOnClickListener { engine.reset() }

        setupSlots()
        setupCounter()
        setupOverlay()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        pending?.let { outState.putString("pending", it.name) }
    }

    override fun onResume() {
        super.onResume()
        b.status.setText(if (serviceEnabled()) R.string.svc_on else R.string.svc_off)
    }

    override fun onDestroy() {
        engine.destroy()
        super.onDestroy()
    }

    // ---------- imagens ----------
    private fun setupSlots() {
        Slot.values().forEach { slot ->
            val row = ItemSlotBinding.inflate(layoutInflater, b.slots, false)
            row.name.setText(slot.label)
            row.pick.setOnClickListener {
                pending = slot
                picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
            }
            row.remove.setOnClickListener { ImageStore.remove(this, slot); imagesChanged() }
            thumbs[slot] = row.thumb
            b.slots.addView(row.root)
        }
        refreshThumbs()
    }

    private fun refreshThumbs() {
        thumbs.forEach { (slot, iv) ->
            val bmp = ImageStore.load(this, slot)
            if (bmp != null) iv.setImageBitmap(bmp) else iv.setImageResource(slot.defRes)
        }
    }

    private fun imagesChanged() {
        cfg.imgVersion++          // avisa o overlay pra recarregar
        clicker.reload()
        refreshThumbs()
    }

    // ---------- contador ----------
    private fun setupCounter() {
        fun limitTxt() {
            b.limitLabel.text =
                if (cfg.limitSec == 0) getString(R.string.limit_none) else getString(R.string.limit_fmt, cfg.limitSec)
        }
        fun sizeTxt() { b.sizeLabel.text = getString(R.string.size_fmt, cfg.textSizeSp) }

        b.limitSlider.value = cfg.limitSec.toFloat()
        b.limitSlider.setLabelFormatter { if (it.toInt() == 0) getString(R.string.limit_none) else "${it.toInt()}s" }
        b.limitSlider.addOnChangeListener { _, v, fromUser ->
            if (fromUser) { cfg.limitSec = v.toInt(); limitTxt() }
        }
        limitTxt()

        b.sizeSlider.value = cfg.textSizeSp.toFloat()
        b.sizeSlider.addOnChangeListener { _, v, fromUser ->
            if (fromUser) { cfg.textSizeSp = v.toInt(); sizeTxt(); clicker.restyle() }
        }
        sizeTxt()

        listOf(0xFFFFFFFF, 0xFFFFEB3B, 0xFF4CAF50, 0xFFF44336, 0xFF00BCD4, 0xFFE040FB).forEach { raw ->
            val c = raw.toInt()
            val dot = View(this).apply {
                background = GradientDrawable().apply {
                    shape = GradientDrawable.OVAL
                    setColor(c)
                    setStroke(dp(2), 0x88888888.toInt())
                }
                layoutParams = LinearLayout.LayoutParams(dp(40), dp(40)).apply { marginEnd = dp(10) }
                contentDescription = getString(R.string.cd_color)
                setOnClickListener { cfg.textColor = c; clicker.restyle() }
            }
            b.colors.addView(dot)
        }

        b.swCounter.isChecked = cfg.showCounter
        b.swCounter.setOnCheckedChangeListener { _, c -> cfg.showCounter = c; clicker.restyle() }
        b.swCps.isChecked = cfg.showCps
        b.swCps.setOnCheckedChangeListener { _, c -> cfg.showCps = c; clicker.restyle() }
    }

    // ---------- overlay / acessibilidade ----------
    private fun setupOverlay() {
        fun ovTxt() { b.overlayLabel.text = getString(R.string.overlay_size_fmt, cfg.overlaySizeDp) }

        b.swOverlay.isChecked = cfg.overlayOn
        b.swOverlay.setOnCheckedChangeListener { _, c ->
            cfg.overlayOn = c
            if (c && !serviceEnabled()) {
                Toast.makeText(this, R.string.enable_toast, Toast.LENGTH_LONG).show()
                openAccessibility()
            }
        }
        b.overlaySlider.value = cfg.overlaySizeDp.toFloat()
        b.overlaySlider.addOnChangeListener { _, v, fromUser ->
            if (fromUser) { cfg.overlaySizeDp = v.toInt(); ovTxt() }
        }
        ovTxt()
        b.btnA11y.setOnClickListener { openAccessibility() }
        b.btnResetPos.setOnClickListener { cfg.setPos(40, 300) }
    }

    private fun openAccessibility() = startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))

    private fun serviceEnabled(): Boolean {
        val am = getSystemService(AccessibilityManager::class.java)
        return am.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK).any {
            it.resolveInfo.serviceInfo.let { s ->
                s.packageName == packageName && s.name == ClickerService::class.java.name
            }
        }
    }
}

package com.aura.clickerinthescreen

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.PixelFormat
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import kotlin.math.roundToInt

/**
 * Hospeda o clicker flutuante usando TYPE_ACCESSIBILITY_OVERLAY (por cima de qualquer app,
 * sem a permissão "sobrepor outros apps"). Não lê o conteúdo da tela.
 */
class ClickerService : AccessibilityService() {

    private val cfg by lazy { Cfg(this) }
    private val wm by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private val engine = ClickEngine { view?.refresh() }
    private var view: ClickerView? = null
    private var lastVer = -1

    private val lp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    // precisa ser propriedade (referência forte), senão o Android descarta o listener
    private val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, _ -> apply() }

    override fun onServiceConnected() {
        cfg.sp.registerOnSharedPreferenceChangeListener(listener)
        apply()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        hide()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        cfg.sp.unregisterOnSharedPreferenceChangeListener(listener)
        hide()
        engine.destroy()
        super.onDestroy()
    }

    private fun apply() {
        if (!cfg.overlayOn) { hide(); return }
        lp.x = cfg.ovX; lp.y = cfg.ovY
        val v = view
        if (v == null) {
            val nv = ClickerView(this, engine, cfg)
            nv.setImageSize(dp(cfg.overlaySizeDp))
            nv.enableTouch(
                onDrag = ::move,
                onDragEnd = { cfg.setPos(lp.x, lp.y) }
            )
            nv.reload()
            lastVer = cfg.imgVersion
            wm.addView(nv, lp)
            view = nv
        } else {
            v.setImageSize(dp(cfg.overlaySizeDp))
            if (cfg.imgVersion != lastVer) { lastVer = cfg.imgVersion; v.reload() } else v.restyle()
            wm.updateViewLayout(v, lp)
        }
    }

    private fun move(dx: Float, dy: Float) {
        val v = view ?: return
        val dm = resources.displayMetrics
        lp.x = (lp.x + dx).roundToInt().coerceIn(0, (dm.widthPixels - v.width).coerceAtLeast(0))
        lp.y = (lp.y + dy).roundToInt().coerceIn(0, (dm.heightPixels - v.height).coerceAtLeast(0))
        wm.updateViewLayout(v, lp)
    }

    private fun hide() {
        view?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        view = null
    }
}
